# news-JS

Run application:

- Rename `.env.example` to `.env` and set variables with your data
- Run command in your terminal `npm start`
