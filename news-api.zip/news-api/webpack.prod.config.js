module.exports = {
  mode: "production",
};
